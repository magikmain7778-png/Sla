extends Node2D

const W := 720.0
const H := 1280.0
var player := Vector2(360, 1060)
var player_radius := 30.0
var obstacles: Array[Dictionary] = []
var spawn_timer := 0.0
var elapsed := 0.0
var score := 0
var best := 0
var game_over := false
var dragging := false
var target_x := 360.0
var stars: Array[Vector3] = []
var font: Font

func _ready() -> void:
	font = ThemeDB.fallback_font
	for i in range(90):
		stars.append(Vector3(randf_range(0, W), randf_range(0, H), randf_range(1.0, 3.0)))
	reset_game()

func reset_game() -> void:
	player = Vector2(W * 0.5, H * 0.82)
	target_x = player.x
	obstacles.clear()
	spawn_timer = 0.0
	elapsed = 0.0
	score = 0
	game_over = false
	queue_redraw()

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			if game_over:
				reset_game()
			else:
				dragging = true
				target_x = _screen_to_game(event.position).x
		else:
			dragging = false
	elif event is InputEventScreenDrag:
		dragging = true
		target_x = _screen_to_game(event.position).x
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			if game_over:
				reset_game()
			else:
				dragging = true
				target_x = _screen_to_game(event.position).x
		else:
			dragging = false
	elif event is InputEventMouseMotion and dragging:
		target_x = _screen_to_game(event.position).x
	elif event is InputEventKey and event.pressed and event.keycode == KEY_SPACE and game_over:
		reset_game()

func _screen_to_game(p: Vector2) -> Vector2:
	var view := get_viewport_rect().size
	return Vector2(p.x * W / maxf(view.x, 1.0), p.y * H / maxf(view.y, 1.0))

func _process(delta: float) -> void:
	if not game_over:
		elapsed += delta
		score = int(elapsed * 10.0)
		player.x = move_toward(player.x, clampf(target_x, 35, W - 35), 1100.0 * delta)
		spawn_timer -= delta
		if spawn_timer <= 0:
			_spawn_obstacle()
			spawn_timer = maxf(0.25, 0.72 - elapsed * 0.008) * randf_range(0.72, 1.22)
		var speed := 360.0 + minf(elapsed * 9.0, 500.0)
		for i in range(obstacles.size() - 1, -1, -1):
			obstacles[i].pos.y += speed * delta
			if obstacles[i].pos.y > H + 100:
				obstacles.remove_at(i)
				continue
			var rect: Rect2 = obstacles[i].rect
			var pos: Vector2 = obstacles[i].pos
			var hit_rect := Rect2(pos.x - rect.size.x * 0.5, pos.y - rect.size.y * 0.5, rect.size.x, rect.size.y)
			if hit_rect.grow(7).has_point(player):
				game_over = true
	queue_redraw()

func _spawn_obstacle() -> void:
	var width := randf_range(70, 145)
	var height := randf_range(28, 48)
	var x := randf_range(width * 0.5 + 12, W - width * 0.5 - 12)
	var col := [Color(1.0, 0.12, 0.48), Color(0.0, 0.95, 1.0), Color(0.72, 0.28, 1.0)][randi_range(0, 2)]
	obstacles.append({"pos": Vector2(x, -70), "rect": Rect2(Vector2.ZERO, Vector2(width, height)), "color": col})

func _draw() -> void:
	var bg := Color(0.025, 0.015, 0.08)
	draw_rect(Rect2(0, 0, W, H), bg)
	for s in stars:
		draw_circle(Vector2(s.x, fposmod(s.y + elapsed * 22.0, H)), s.z, Color(0.30, 0.22, 0.55, 0.6))
	for x in range(0, int(W) + 1, 60):
		draw_line(Vector2(x, 0), Vector2(x, H), Color(0.14, 0.10, 0.28, 0.35), 1.0)
	for y in range(0, int(H) + 1, 60):
		draw_line(Vector2(0, y), Vector2(W, y), Color(0.14, 0.10, 0.28, 0.35), 1.0)
	for ob in obstacles:
		var p: Vector2 = ob.pos
		var r: Rect2 = ob.rect
		var c: Color = ob.color
		var rr := Rect2(p.x - r.size.x * 0.5, p.y - r.size.y * 0.5, r.size.x, r.size.y)
		draw_rect(rr.grow(7), Color(c.r, c.g, c.b, 0.16), true)
		draw_rect(rr, c, true)
		draw_rect(rr, Color(1, 1, 1, 0.8), false, 2.0)
	# Player glow and diamond
	draw_circle(player, player_radius + 18, Color(0.0, 0.9, 1.0, 0.12))
	draw_circle(player, player_radius + 8, Color(0.0, 0.9, 1.0, 0.22))
	var points := PackedVector2Array([player + Vector2(0, -player_radius), player + Vector2(player_radius * 0.78, 0), player + Vector2(0, player_radius), player + Vector2(-player_radius * 0.78, 0)])
	draw_colored_polygon(points, Color(0.10, 0.95, 1.0))
	draw_polyline(PackedVector2Array([points[0], points[1], points[2], points[3], points[0]]), Color.WHITE, 3.0, true)
	_draw_text("NEON DODGE", Vector2(34, 74), 46, Color(0.2, 0.95, 1.0))
	_draw_text("SCORE  %06d" % score, Vector2(36, 124), 26, Color.WHITE)
	_draw_text("DRAG TO MOVE  •  DODGE THE NEON", Vector2(36, H - 45), 20, Color(0.65, 0.62, 0.82))
	if game_over:
		draw_rect(Rect2(0, 0, W, H), Color(0.015, 0.005, 0.04, 0.78))
		_draw_text("GAME OVER", Vector2(120, 540), 62, Color(1.0, 0.18, 0.5))
		_draw_text("SCORE  %06d" % score, Vector2(205, 615), 34, Color.WHITE)
		_draw_text("TOQUE PARA JOGAR DE NOVO", Vector2(112, 700), 25, Color(0.15, 0.95, 1.0))

func _draw_text(txt: String, pos: Vector2, size: int, color: Color) -> void:
	draw_string(font, pos, txt, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)
