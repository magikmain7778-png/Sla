NEON DODGE - projeto Godot para Android

Projeto base: Godot 4.2 / GL Compatibility.
Inclui movimentacao por toque, obstaculos neon, pontuacao e reinicio.

BUILD AUTOMATICO DO APK PELO GITHUB ACTIONS
1. Crie um repositorio no GitHub.
2. Extraia ESTE ZIP no celular e envie os arquivos e pastas para a raiz do repositorio.
   Importante: a pasta .github/workflows/build-apk.yml precisa ser enviada tambem.
   Se o GitHub nao mostrar pastas iniciadas por ponto no seletor, use o site em modo desktop ou envie os arquivos por outro metodo.
3. Abra a aba Actions do repositorio.
4. Se necessario, confirme Enable workflows.
5. Escolha Build APK (Godot) e toque Run workflow.
6. Espere a execucao terminar com sucesso; abra a execucao e baixe o Artifact chamado NeonDodge-teste.N (o numero muda a cada execucao).
7. Extraia o ZIP do Artifact e instale o APK no Android.

O workflow usa Godot 4.2.2, Java 17 e Android SDK no runner do GitHub.
O APK e de debug e tem arquitetura ARM64. O APK so existe depois que a execucao terminar com sucesso.
